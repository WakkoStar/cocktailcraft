const client = require('../utils/bdd')


module.exports.getAllIngredients = async() => {
    const res = await client.query('SELECT * FROM ingredient ORDER BY name')
    return res.rows
}

module.exports.createIngredient = (name, aliases) => {
    const text = 'INSERT INTO ingredient (name, aliases) VALUES ($1, $2)'
    const values = [name, aliases]

    client.query(text, values, (err, res) => {
        if (err) console.log(err.stack)
    })
}

module.exports.modifyIngredient = (name,aliases, id) => {
    const text =  'UPDATE ingredient SET name = $1, aliases=$2   WHERE id = $3'
    const values = [name,aliases, id]

    client.query(text, values, (err, res) => {
        if (err) console.log(err.stack)
    })
}

module.exports.deleteIngredient = (id) => {
    const text = 'DELETE FROM ingredient WHERE id = $1'
    const values = [id]

    client.query(text, values, (err, res) => {
        if (err) console.log(err.stack)
    })
}
